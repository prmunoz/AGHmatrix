#########################################################################
# 									#
# Package: AGHmatrix 							#
# 									#
# File: sortped.R							#
# Contains: sortped 							#
# 									#
# Written by Rodrigo Rampazo Amadeu 					#
# 									#
# First version: Dec-2015 						#
# Last update: 14-Jan-2016 						#
# License: GNU General Public License version 2 (June, 1991) or later 	#
# 									#
#########################################################################

#' Organizes pedigree data in a chronological way
#'
#' This function organizes pedigree data in a chronological way and return 3 lists: i) parental 1 values (numeric); ii) parental 2 values (numeric); iii) real names of the individuals. Also save a .txt file with new pedigree file.
#' @param data name of the pedigree data. Default=NULL.
#' @param loop.in max number of iteractions to get the chronological order inside a column (e.g. parental 1 or parental 2). Default = 1000
#' @param loop.between max number of iteractions to get the chronological order between columns. Default=100.
#' @param print if TRUE print the step-by-step of the loops. Default=FALSE. 
#'
#' @return list with parental 1, parental 2, and real names of the individuals (key) also saves a txt file with the new chronological pedigree.
#'
#' @examples data.treat()
#'
#' @author Rodrigo R Amadeu, \email{rramadeu@@gmail.com}
#'
#' @export

sortped<-function(data = NULL, loop.in = 1000, loop.between = 100, print = FALSE)
{   
    if (is.null(data)) 
        stop(deparse("Please define the variable data"))

    stop.loop.1 <- stop.loop.2 <- FALSE
    
    for(j in 1:loop.between){
        if(print) cat(paste("looping between...",print(j)))
        
        for(i in 1:loop.in){
            if(print) cat(paste("looping in first parent...",print(i)))
            ind<-data[,1]
            sire<-data[,2]
            dire<-data[,3]
            index<-1:length(ind)
            compare<-match(dire,ind)
            compare[which(is.na(compare))]<-0
            loop<-which(compare>index)
            newindex<-index
            newindex[loop[1]]<-compare[loop[1]]
            newindex[compare[loop[1]]]<-loop[1]
            data<-data[newindex,]
            if(print) print(length(loop))
            if( length(loop) == 0 && i == 1)
                stop.loop.1 <- TRUE
            if(length(loop)==0) break
        }

        for(i in 1:loop.in){
            if(print) cat(paste("looping in second parent...",print(i))) 
            ind<-data[,1]
            sire<-data[,2]
            dire<-data[,3]
            index<-1:length(ind)
            compare<-match(sire,ind)
            compare[which(is.na(compare))]<-0
            loop<-which(compare>index)
            newindex<-index
            newindex[loop[1]]<-compare[loop[1]]
            newindex[compare[loop[1]]]<-loop[1]
            data<-data[newindex,]
            if(print) print(length(loop))
            if( length(loop) == 0 && i == 1)
                stop.loop.2 <- TRUE
            if( length(loop) == 0 ) break
        }
        
        if( stop.loop.1 && stop.loop.2) break
    }
    return(data)
}
