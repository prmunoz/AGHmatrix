#########################################################################
# 									#
# Package: AGHmatrix 							#
# 									#
# File: Gmatrix.R 							#
# Contains: Gmatrix 							#
# 									#
# Written by Rodrigo Rampazo Amadeu 					#
# 									#
# First version: Feb-2014 						#
# Last update: 14-Apr-2015 						#
# License: GNU General Public License version 2 (June, 1991) or later 	#
# 									#
#########################################################################

#' Construction of Relationship Matrix G
#'
#' Given a molecular data from 'converttofrequency' function and choosing a method ((1) Powell or (2) VanRaden), a missing value, and a maf threshold, return a G matrix. Also the function can calculate the number of markers shared two-by-two individuals (method 3)
#'
#' @param SNPdata data from 'converttofrequency' function.
#' @param SNPfile file created with 'converttofrequency' function.
#' @param method "Powell" (1), "VanRaden" (2), shared markers (3). Default=2.
#' @param missingValue which is the missing value in data. Default=NA.
#' @param maf max of missing data accepted to each marker. Default=0.05.
#'
#' @return Matrix with the Relationship between the individuals
#'
#' @examples Gmatrix()
#'
#' @author Rodrigo R Amadeu, \email{rramadeu@@gmail.com}
#'
#' @references \emph{Van Raden, P. M. (2008). Efficient methods to compute genomic predictions. Journal of Dairy Science, 91(11), 4414-4423.}
#' @references \emph{Powell, J. E. (2010). Reconciling the analysis of IBD and IBS in complex trait studies. Nature Reviews Genetics, 11(11), 800-805.}
#'
#' @export

Gmatrix = function( SNPdata = NULL,
                    SNPfile = NULL,
                    method = 2,
                    missingValue=NA,
                    maf = 0.05){

    Time = proc.time()

    if(is.null(SNPdata)&is.null(SNPfile)){
        stop(deparse("Please define the variable SNPdata or the path for SNPfile"))
    }
    if(!is.null(SNPdata)&!is.null(SNPfile)){
        stop(deparse("SNPdata and SNPfile are mutually exclusive. Please choose only one."))
  }
    if (missing(missingValue)){ stop(deparse("missingValue not defined"))}

    if (!is.null(SNPdata)){
        SNPdata = as.matrix(SNPdata)
    } else {
        file = read.csv(SNPfile,header = TRUE,check.names = FALSE,row.names = 1)
        SNPdata = as.matrix(file)
    }
    if(method==1)
        method="Powell"
    if(method==2)
        method="VanRaden"
    if(method==3)
        method="MarkersMatrix"

    if (all(method != c("Powell","VanRaden","MarkersMatrix"))){ stop("Method to build Gmatrix has to be either (1) Powell or (2) VanRaden or (3) for the Amount of Markers Between Individuals  Matrix") }

    SNPmatrix = matrix(as.numeric(SNPdata),ncol = ncol(SNPdata),dimnames = list(c(rownames(SNPdata)),c(colnames(SNPdata))))

    if (!is.na(missingValue)){
        m <- match(SNPmatrix, missingValue ,0)
        SNPmatrix[m > 0] <- NA
    }

    NumberMarkers = ncol(SNPmatrix)
    nindTotal = colSums(!is.na(SNPmatrix))

    cat("	Number of Markers:",max(NumberMarkers),"\n")
    cat("	Number of Individuals:",max(nindTotal),"\n\n")

    alelleFreq = colSums(SNPmatrix,na.rm=TRUE)/nindTotal

    if( maf > 0){
        exclude <- c(which(alelleFreq<=maf),which(alelleFreq>=(1-maf)))
        if(length(exclude)>0){
            SNPmatrix <- SNPmatrix[,-exclude]
            alelleFreq = alelleFreq[-exclude]
        }
    }

    if(method=="MarkersMatrix"){ #calculate the number of markers for each ind pair
        Gmatrix <- t(!is.na(SNPmatrix))
        Gmatrix <- crossprod(Gmatrix,Gmatrix)
        return(Gmatrix)
    }

    NumberMarkers = ncol(SNPmatrix)

    Frequency = cbind((1-alelleFreq),alelleFreq)
    FreqP<-alelleFreq

    Pmatrix <- matrix(rep(alelleFreq,max(nindTotal)),nrow=max(nindTotal),byrow=TRUE)

    if( method=="VanRaden"){
        Zmatrix <- 2*(SNPmatrix-Pmatrix)
        Zmatrix[is.na(Zmatrix)] = 0 #Missing Values
        Gmatrix <- crossprod(t(Zmatrix),t(Zmatrix))
        sumpi <- sum(alelleFreq*(1-alelleFreq))
        Gmatrix <- Gmatrix/(2*sumpi)
    }

    if( method == "Powell"){
        SNPmatrix <- t(SNPmatrix)
        SNP.Visscher <- 2*as.matrix(t(SNPmatrix))
        FreqPQ = matrix(rep(2*Frequency[,1] * Frequency[,2],each = ncol(SNPmatrix)),ncol = nrow(SNPmatrix))
        G.all = (SNP.Visscher^2 - (1+2*Pmatrix)*SNP.Visscher + 2*Pmatrix^2)/FreqPQ
        G.ii = as.matrix(colSums(t(G.all),na.rm = T))
        SNP.Visscher= (SNP.Visscher-(2*Pmatrix))/sqrt(FreqPQ)
        G.ii.hat = 1+(G.ii)/max(NumberMarkers)
        SNP.Visscher[is.na(SNP.Visscher)] <- 0
        Gmatrix = (crossprod(t(SNP.Visscher),t(SNP.Visscher)))/max(NumberMarkers)
        diag(Gmatrix) = G.ii.hat
    }


    Time = as.matrix(proc.time()-Time)
    cat("Completed! Time =", Time[3]," seconds \n")
    return(Gmatrix)

                                        # save(output, file=paste("Gmatrix_",method,".RData",sep=""))
   # print(paste("Saved  as 'Gmatrix_",method,".RData",sep=""))
}
