#########################################################################
# 									#
# Package: AGHmatrix 							#
# 									#
# File: Amatrix.R 							#
# Contains: Amatrix 							#
# 									#
# Written by Rodrigo Rampazo Amadeu 					#
# 									#
# First version: Feb-2014 						#
# Last update: 14-Apr-2015 						#
# License: GNU General Public License version 2 (June, 1991) or later 	#
# 									#
#########################################################################

#' Construction of Relationship Matrix A
#'
#' Creates a Relationship Matrix A from a pedigree data in a 3-column way format based on ploidy level (2 or 4) and, if ploidy equals 4, based on proportion of parental gametes that are IBD (Identical by Descent) due to double reduction.
#'
#' @param data pedigree data name (3-column way format).
#' @param ploidy 2 or 4 (default=2).
#' @param w proportion of parental gametas IBD due to double reduction (default=0). 
#' @param unk string or number indicating the unknown value related in the pedigree file (default=0).
#' @param verify verifies pedigree file for conflictuos entries (default=TRUE).
#'
#' @return Matrix with the Relationship between the individuals.
#'
#' @examples
#' data(ped.mrode)
#' #Build Amatrix diploid (no double reduction proportion)
#' Amatrix(data=ped.mrode,ploidy=2,unk=0)
#' #Build Amatrix autotetraploidy (double reduction proportion=0.1)
#' Amatrix(data=ped.mrode,ploidy=4,w=0.1,unk=0)
#'
#' @author Rodrigo R Amadeu, \email{rramadeu@@gmail.com}
#'
#' @references \emph{Chapter 2: Genetic Covariance Between Relatives in Mrode, R. A., and Thompson, R. Linear models for the prediction of animal breeding values. Cabi, 2005.}
#' @references \emph{Slater, A. T., Wilson, G. M., Cogan, N. O., Forster, J. W., & Hayes, B. J. (2013). Improving the analysis of low heritability complex traits for enhanced genetic gain in potato. Theoretical and Applied Genetics, 1-12.}
#'
#' @export

Amatrix <- function(data = NULL,
                    ploidy=2,
                    w=0,
                    unk=0,
		    verify=TRUE)
    {
  if(ploidy!=2)
      if(ploidy!=4)
          stop(deparse("Ploidy should be 2 or 4"))

  if( is.null(data))
    stop(deparse("Please define the variable data"))

  cat("Verifying conflicting data... \n")
  flag<-verifyped(data)
  if(flag) 
    stop(deparse("Please double-check your data and try again"))
    

  cat("Organizing data... \n")
  data <- data.treat(data=data,unk=unk,n.max=50,save=FALSE)

  s <- data$sire
  d <- data$dire

  if( is.null(s) || is.null(d) )
    stop(deparse("Please define the variable s (sire) and/or d (dire)"))

  if( length(s) != length(d) )
    stop(deparse("Please verify the variable s (sire) and/or d (dire), they don't have the same length"))

  if( !is.numeric(s) || !is.numeric(d) )
    stop(deparse("Pleasy verify your data, it has to be 2 numeric vectors"))

  if( length(data$sire) > 1000 )
     cat("Processing a large pedigree data... It may take a couple of minutes... \n")


  n <- length(s)
  A <- matrix(NA,ncol=n,nrow=n)

  Time = proc.time()

#### For ploidy 2 ####
  if(ploidy == 2){
  w <- NA
  cat("Constructing matrix A using ploidy = 2 \n")
    A[1,1] <- 1
    for( i in 2:n){

      ## Both are unknown
      if( s[i] == 0 && d[i] == 0 ){
        A[i,i] <- 1
        for( j in 1:(i-1))
          A[j,i] <- A[i,j] <- 0
      }

      ## Sire is unknown
      if( s[i] == 0 && d[i] != 0 ){
        A[i,i] <- 1
        for( j in 1:(i-1))
          A[j,i] <- A[i,j] <- 0.5*(A[j,d[i]])
      }

      ## Dire is unknown
      if( d[i] == 0 && s[i] != 0 ){
        A[i,i] <- 1
        for( j in 1:(i-1))
          A[j,i] <- A[i,j] <- 0.5*(A[j,s[i]])
      }

      ## Both are known
      if( d[i] != 0 && s[i] != 0 ){
        A[i,i] <- 1+0.5*(A[d[i],s[i]])
        for( j in 1:(i-1))
          A[j,i] <- A[i,j] <- 0.5*(A[j,s[i]]+A[j,d[i]])
      }
    }

  NA.errors <- which(is.na(A))
  if( length(NA.errors) > 0 )
      cat("Please verify your original data with the function 'verifyped', there are some data missing/conflicting data \n")

  }

#### For ploidy 4 ####
  if(ploidy == 4){
    listA <- list()

      cat(paste("Constructing matrix A using ploidy = 4 and proportion of double reduction = ",w,"\n"))
      start.time <- Sys.time()

      A[1,1] <- (1+w)/4
      for( i in 2:n){

      ## Both are unknown
        if( s[i] == 0 && d[i] == 0 ){
          A[i,i] <- (1+w)/4
          for( j in 1:(i-1))
            A[j,i] <- A[i,j] <- 0
        }

        ## Sire is unknown
        if( s[i] == 0 && d[i] != 0 ){
          A[i,i] <- (5 + 7*w + 4*A[d[i],d[i]]*(1-w) ) / 24
          for( j in 1:(i-1))
            A[j,i] <- A[i,j] <- 0.5*(A[j,d[i]])
        }

        ## Dire is unknown
        if( d[i] == 0 && s[i] != 0 ){
          A[i,i] <- (5 + 7*w + 4*A[s[i],s[i]]*(1-w) ) / 24
          for( j in 1:(i-1))
            A[j,i] <- A[i,j] <- 0.5*(A[j,s[i]])
        }

        ## Both are known
        if( d[i] != 0 && s[i] != 0 ){
          A[i,i] <- (1 + 2*w + (1-w)*(A[s[i],s[i]]) + (1-w)*(A[d[i],d[i]]) + 3*A[s[i],d[i]] ) / 6
          for( j in 1:(i-1))
            A[j,i] <- A[i,j] <- 0.5*(A[j,s[i]]+A[j,d[i]])
        }
      }

    NA.errors <- which(is.na(A))
    if( length(NA.errors) > 0 )
      cat("Please verify your original data with the function 'verifyped', there are some data missing/conflicting data \n")
    A <- 4*A
}

  Time = as.matrix(proc.time()-Time)
  cat("Completed! Time =", Time[3]/60," minutes \n")
#      "Visualization options: (matrix, w) \n ")

  rownames(A) <- colnames(A) <- data$ind.data

  #listA <- list(w=w,matrix=A)
  #structure(listA,class="gen.data")
  return(A)
}
